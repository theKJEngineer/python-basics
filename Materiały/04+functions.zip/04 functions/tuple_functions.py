
tuple1 = (1,2,3,4) + (5,) + tuple([6,7])
print( type(tuple1) )
print( tuple1 )

print( (1,2) * 4 )

print( 9 in tuple1 )
print( tuple1[1] )
print( len(tuple1) )

print( min(tuple1) )
print( max(tuple1) )