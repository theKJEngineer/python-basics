
def printCar(brand, name = "concept", year = 1960, color = "black"):
    print(brand, name,year, color)


printCar("Ford")
printCar("Ford", "Mustang")
printCar("Ford", "Mustang", 1970)
printCar("Ford", "Mustang", 1970, "red")
