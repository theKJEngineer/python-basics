
def printCar(brand, name = "concept", year = 1960, color = "black"):
    print(brand, name,year, color)


printCar(name = "T", brand = "Ford")
printCar(name = "T", year = 1920, brand = "Ford")

